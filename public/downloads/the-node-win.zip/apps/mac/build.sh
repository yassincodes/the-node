#!/bin/bash
# Build The Node.app + zip for adopt download.
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$ROOT/dist"
APP="$OUT/The Node.app"
ZIP="$ROOT/public/downloads/the-node-mac.zip"

rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources/engine"

cp "$ROOT/apps/mac/Info.plist" "$APP/Contents/Info.plist"
cp "$ROOT/apps/mac/launch" "$APP/Contents/MacOS/launch"
cp "$ROOT/apps/mac/terminal-run" "$APP/Contents/Resources/terminal-run"
chmod +x "$APP/Contents/MacOS/launch" "$APP/Contents/Resources/terminal-run"

rsync -a "$ROOT/" "$APP/Contents/Resources/engine/" \
  --exclude '.git' --exclude '.venv' --exclude 'dist' --exclude '__pycache__' \
  --exclude '.env' --exclude 'layers/learn.json' --exclude 'layers/history.json' \
  --exclude '.thenode-try' --exclude 'node_modules' --exclude 'public/downloads'

# Never ship a venv — it breaks on every machine. Fresh venv on first open.
rm -rf "$APP/Contents/Resources/engine/.venv"

cp "$ROOT/apps/mac/Open.command" "$OUT/Adopt.command"
chmod +x "$OUT/Adopt.command"

if command -v codesign >/dev/null 2>&1; then
  codesign --force --deep --sign - "$APP" 2>/dev/null || true
fi

# No quarantine on local build
xattr -cr "$APP" 2>/dev/null || true

mkdir -p "$ROOT/public/downloads"
chmod +x "$ROOT/public/downloads/Adopt.command"
rm -f "$ZIP"
(cd "$OUT" && zip -rq "$ZIP" "The Node.app")


echo ""
echo "  Built: $APP"
echo "  Zip:   $ZIP"
echo "  After Safari download: unzip → double-click Adopt.command"
echo ""
