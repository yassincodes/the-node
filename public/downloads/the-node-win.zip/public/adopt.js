/**
 * Adoption — detects hardware, serves the right download.
 * User only sees "Adopt". The page knows the machine.
 */
(function (global) {
  var GITHUB = "https://github.com/yassincodes/the-node";

  function parseUA() {
    var ua = navigator.userAgent || "";
    var platform = navigator.platform || "";
    if (/iPhone|iPad|iPod/i.test(ua)) return { os: "ios", arch: "arm" };
    if (/Android/i.test(ua)) return { os: "android", arch: "arm" };
    if (/Win/i.test(ua) || platform === "Win32") return { os: "windows", arch: /x64|WOW64|Win64/i.test(ua) ? "x64" : "x86" };
    if (/Mac/i.test(ua) || platform === "MacIntel") {
      return { os: "mac", arch: /aarch64|arm64/i.test(ua) ? "arm64" : "x64" };
    }
    if (/Linux/i.test(ua)) return { os: "linux", arch: /aarch64|arm64/i.test(ua) ? "arm64" : "x64" };
    return { os: "unknown", arch: "unknown" };
  }

  function detect() {
    return new Promise(function (resolve) {
      if (navigator.userAgentData && navigator.userAgentData.getHighEntropyValues) {
        navigator.userAgentData
          .getHighEntropyValues(["platform", "architecture", "bitness"])
          .then(function (h) {
            var os = "unknown";
            var p = (h.platform || "").toLowerCase();
            if (p === "macos") os = "mac";
            else if (p === "windows") os = "windows";
            else if (p === "linux") os = "linux";
            else if (p === "android") os = "android";
            else if (/ios/i.test(navigator.userAgent)) os = "ios";
            resolve({ os: os, arch: (h.architecture || "unknown").toLowerCase(), source: "ua-client-hints" });
          })
          .catch(function () { resolve(Object.assign(parseUA(), { source: "ua" })); });
      } else {
        resolve(Object.assign(parseUA(), { source: "ua" }));
      }
    });
  }

  function downloadBlob(blob, filename) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function downloadUrl(url, filename) {
    var a = document.createElement("a");
    a.href = url;
    a.download = filename || "";
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function macInstaller(origin) {
    return fetch("/downloads/Adopt.command")
      .then(function (r) { return r.text(); })
      .then(function (tpl) {
        var script = tpl.replace("__THenode_ORIGIN__", origin.replace(/\/$/, ""));
        var blob = new Blob([script], { type: "application/x-sh" });
        downloadBlob(blob, "Adopt.command");
      });
  }

  function adopt(hardware) {
    var os = hardware.os;
    var spec = {
      mac: { url: "/downloads/the-node-mac.zip", name: "The Node.zip" },
      windows: { url: "/downloads/the-node-win.zip", name: "The Node.zip" }
    }[os];
    if (!spec) return Promise.resolve({ ok: false, os: os });

    return fetch(spec.url).then(function (r) {
      if (!r.ok) throw new Error("missing");
      return r.blob();
    }).then(function (blob) {
      downloadBlob(blob, spec.name);
      return { ok: true, os: os };
    });
  }

  global.TheNodeAdopt = { detect: detect, adopt: adopt, learnUrl: GITHUB };
})(window);
