#!/bin/bash
cd "$(dirname "$0")"
clear
echo ""
echo "  ┌─────────────────────────────┐"
echo "  │         The Node            │"
echo "  └─────────────────────────────┘"
echo ""
echo "  Bringing yours to life on this computer."
echo "  The browser will open. Follow what you see."
echo ""
if [ ! -d ".venv" ]; then
  echo "  First time — installing (one minute)..."
  ./setup.sh
else
  ./try
fi
echo ""
echo "  Your node is on this machine now."
echo ""
read -r -p "  Press Enter to close this window… " _
