#!/bin/bash
# Dev shortcut — build locally from this repo (same as site Adopt, no download).
set -e
cd "$(dirname "$0")"
bash apps/mac/build.sh
INSTALL="$HOME/Applications/The Node"
mkdir -p "$INSTALL"
rm -rf "$INSTALL/The Node.app"
ditto "dist/The Node.app" "$INSTALL/"
echo ""
echo "  Installed to Applications → The Node"
open "$INSTALL/The Node.app"
