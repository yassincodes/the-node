/**
 * Adoption — Mac: notarized DMG (open, drag to Applications, done).
 * Windows: zip download.
 */
(function (global) {
  var GITHUB = "https://github.com/yassincodes/the-node";
  var MAC_DMG =
    "https://github.com/yassincodes/the-node/releases/latest/download/The-Node.dmg";
  var MAC_FALLBACK = "/downloads/The-Node.dmg";
  var MAC_ZIP_FALLBACK = "/downloads/the-node-mac.zip";

  function parseUA() {
    var ua = navigator.userAgent || "";
    var platform = navigator.platform || "";
    if (/iPhone|iPad|iPod/i.test(ua)) return { os: "ios", arch: "arm" };
    if (/Android/i.test(ua)) return { os: "android", arch: "arm" };
    if (/Win/i.test(ua) || platform === "Win32") return { os: "windows", arch: /x64|WOW64|Win64/i.test(ua) ? "x64" : "x86" };
    if (/Mac/i.test(ua) || platform === "MacIntel") {
      return { os: "mac", arch: /aarch64|arm64/i.test(ua) ? "arm64" : "x64" };
    }
    if (/Linux/i.test(ua)) return { os: "linux", arch: /aarch64|arm64/i.test(ua) ? "arm64" : "x64" };
    return { os: "unknown", arch: "unknown" };
  }

  function detect() {
    return new Promise(function (resolve) {
      if (navigator.userAgentData && navigator.userAgentData.getHighEntropyValues) {
        navigator.userAgentData
          .getHighEntropyValues(["platform", "architecture", "bitness"])
          .then(function (h) {
            var os = "unknown";
            var p = (h.platform || "").toLowerCase();
            if (p === "macos") os = "mac";
            else if (p === "windows") os = "windows";
            else if (p === "linux") os = "linux";
            else if (p === "android") os = "android";
            else if (/ios/i.test(navigator.userAgent)) os = "ios";
            resolve({ os: os, arch: (h.architecture || "unknown").toLowerCase(), source: "ua-client-hints" });
          })
          .catch(function () { resolve(Object.assign(parseUA(), { source: "ua" })); });
      } else {
        resolve(Object.assign(parseUA(), { source: "ua" }));
      }
    });
  }

  function downloadBlob(blob, filename) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function flashAdopt(text, ms) {
    var btn = document.getElementById("adopt");
    if (!btn) return;
    var orig = btn.textContent;
    btn.textContent = text;
    setTimeout(function () { btn.textContent = orig; }, ms || 8000);
  }

  function go(url) {
    var a = document.createElement("a");
    a.href = url;
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function fetchBlob(url, filename) {
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error("missing");
      return r.blob();
    }).then(function (blob) {
      downloadBlob(blob, filename);
    });
  }

  function macAdopt() {
    flashAdopt("downloading…");
    return fetch(MAC_FALLBACK, { method: "HEAD" })
      .then(function (r) {
        if (r.ok) {
          go(MAC_FALLBACK);
          flashAdopt("open it, drag to Applications");
          return { ok: true, os: "mac" };
        }
        throw new Error("no local dmg");
      })
      .catch(function () {
        go(MAC_DMG);
        flashAdopt("open it, drag to Applications");
        return { ok: true, os: "mac" };
      });
  }

  function adopt(hardware) {
    var os = hardware.os;
    if (os === "mac") return macAdopt();
    if (os === "windows") {
      return fetchBlob("/downloads/the-node-win.zip", "The Node.zip").then(function () {
        return { ok: true, os: os };
      });
    }
    return Promise.resolve({ ok: false, os: os });
  }

  global.TheNodeAdopt = { detect: detect, adopt: adopt, learnUrl: GITHUB };
})(window);
